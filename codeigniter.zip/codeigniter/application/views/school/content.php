<body>
<div class="container">

  <?php if(!empty(validation_errors())){ ?>
  <div class='alert alert-warning'><?php  echo validation_errors(); ?></div>
  <?php } ?>
  <?php

//signup status
  if(isset($data)){

    if($data==1)
          echo'<div class="alert alert-success">Signup success.</div>';
      else
          echo'<div class="alert alert-success">Signup success.</div>';
   }
//login errors
  if(isset($login)){

    if($login==0)
          echo'<div class="alert alert-success">login Failed Please Try Again.</div>';
      
   }


  ?>
  
</div>