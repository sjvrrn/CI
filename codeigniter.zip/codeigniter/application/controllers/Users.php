<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

/*
 *construct
 */
public function __construct(){
	parent::__construct();
	$this->load->model('user');
	$this->load->helper(array('form','url'));
	$this->load->library('form_validation');
	$this->load->library('session');
	
}
/*
 *index page
 */
public function index()
{
	$this->load->view('school/header');
	$this->load->view('school/menu');
	$this->load->view('school/content');
	$this->load->view('school/footer');
}

/*
 *signup
 */	
public function signup(){
	$this->form_validation->set_rules('name','name','required');
	$this->form_validation->set_rules('email','email','required');
	$this->form_validation->set_rules('password','password','required');
	$this->form_validation->set_rules('mobile','mobile','required');
if($this->form_validation->run())
{
	$name = $this->input->post('name');
	$email = $this->input->post('email');
	$password = $this->input->post('password');
	$mobile = $this->input->post('mobile');
	$data = array('name'=>$name,'email'=>$email,'password'=>$password,'mobile'=>$mobile);
	$signup = $this->user->signup($data);
	if($signup){

		$data = array('data'=>'1');
	    $this->load->view('school/header');
		$this->load->view('school/menu');
		$this->load->view('school/content',$data);
		$this->load->view('school/footer');

	}else{

	    $data = array('data'=>'1');
		$this->load->view('school/header');
		$this->load->view('school/menu');
		$this->load->view('school/content',$data);
		$this->load->view('school/footer');

	}

}else{

	$this->load->view('school/header');
	$this->load->view('school/menu');
	$this->load->view('school/content');
	$this->load->view('school/footer');
}

}
/*
 *login
 */	
public function login(){  
	$this->form_validation->set_rules('email','Email','required');
	$this->form_validation->set_rules('password','password','required');

	if($this->form_validation->run()){
         $data  = array('email'=>$this->input->post('email'),'password'=>$this->input->post('password'));
         $login = $this->user->login($data);
         if($login){ 
         	       $this->session->set_userdata((array)$login);
         	       redirect('user/panel');
         }else{
         	$data = array('login',0);
	         	$this->load->view('school/header');
				$this->load->view('school/menu');
				$this->load->view('school/content',$data);
				$this->load->view('school/footer');

         }
           
	}else{ 
			$this->load->view('school/header');
			$this->load->view('school/menu');
			$this->load->view('school/content');
			$this->load->view('school/footer');
	}
 
}
/*
 *panel
 */	
public function panel(){
	$data = $this->session->userdata();
	$data = array('userData'=>$data);
	$this->load->view('school/header');
	$this->load->view('school/menu');
    $this->load->view('school/panel',$data);
    $this->load->view('school/footer');

}
/*
 *update
 */	
public function update(){
$id = $this->uri->segment(2);
$
}

}
