<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-04-07 12:14:20 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 12:14:25 --> 404 Page Not Found: Signup/index
ERROR - 2019-04-07 12:15:38 --> 404 Page Not Found: Signup/index
ERROR - 2019-04-07 12:16:51 --> 404 Page Not Found: Signup/index
ERROR - 2019-04-07 12:17:26 --> 404 Page Not Found: Signup/index
ERROR - 2019-04-07 12:18:49 --> 404 Page Not Found: Users/login
ERROR - 2019-04-07 12:19:51 --> Severity: error --> Exception: syntax error, unexpected '$route' (T_VARIABLE) C:\xampp\htdocs\codeigniter\application\config\routes.php 56
ERROR - 2019-04-07 12:19:57 --> Severity: error --> Exception: syntax error, unexpected '$route' (T_VARIABLE) C:\xampp\htdocs\codeigniter\application\config\routes.php 56
ERROR - 2019-04-07 12:20:48 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:22:28 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:22:29 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:22:29 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:22:30 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:23:11 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:23:13 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:23:13 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:23:13 --> 404 Page Not Found: User/check
ERROR - 2019-04-07 12:24:31 --> 404 Page Not Found: User/signup
ERROR - 2019-04-07 12:26:04 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 12:26:14 --> Severity: error --> Exception: Call to undefined method Users::input() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 31
ERROR - 2019-04-07 12:35:37 --> Severity: error --> Exception: Call to undefined function view() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 39
ERROR - 2019-04-07 12:38:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\codeigniter\application\views\school\content.php 3
ERROR - 2019-04-07 12:41:15 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 12:41:42 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 12:41:47 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 12:42:00 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 12:42:46 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\xampp\htdocs\codeigniter\application\views\school\content.php 3
ERROR - 2019-04-07 12:43:42 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 12:55:08 --> Unable to load the requested class: Database
ERROR - 2019-04-07 12:57:29 --> Unable to load the requested class: Database
ERROR - 2019-04-07 12:57:45 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 12:58:04 --> Severity: Notice --> Undefined variable: request C:\xampp\htdocs\codeigniter\application\controllers\Users.php 42
ERROR - 2019-04-07 13:02:28 --> Severity: Notice --> Undefined variable: singup C:\xampp\htdocs\codeigniter\application\controllers\Users.php 43
ERROR - 2019-04-07 13:04:15 --> 404 Page Not Found: School/panel
ERROR - 2019-04-07 13:07:40 --> 404 Page Not Found: School/panel
ERROR - 2019-04-07 13:07:42 --> 404 Page Not Found: School/panel
ERROR - 2019-04-07 13:07:50 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 13:14:26 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:14:40 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 13:16:15 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 13:24:03 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:24:10 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:25:14 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting variable (T_VARIABLE) or ${ (T_DOLLAR_OPEN_CURLY_BRACES) or {$ (T_CURLY_OPEN) C:\xampp\htdocs\codeigniter\application\controllers\Users.php 99
ERROR - 2019-04-07 13:25:38 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:25:43 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:25:47 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 13:25:51 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:28:26 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:28:48 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:35:52 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:35:56 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:40:40 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 13:40:48 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\codeigniter\application\models\User.php 33
ERROR - 2019-04-07 13:42:48 --> Severity: Notice --> Undefined index: email C:\xampp\htdocs\codeigniter\application\models\User.php 33
ERROR - 2019-04-07 13:53:50 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given C:\xampp\htdocs\codeigniter\system\database\DB_driver.php 1048
ERROR - 2019-04-07 13:53:50 --> Severity: Warning --> preg_match() expects parameter 2 to be string, object given C:\xampp\htdocs\codeigniter\system\database\drivers\mysqli\mysqli_driver.php 324
ERROR - 2019-04-07 13:53:50 --> Severity: Warning --> mysqli::query() expects parameter 1 to be string, object given C:\xampp\htdocs\codeigniter\system\database\drivers\mysqli\mysqli_driver.php 307
ERROR - 2019-04-07 14:15:05 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE), expecting function (T_FUNCTION) C:\xampp\htdocs\codeigniter\application\controllers\Users.php 96
ERROR - 2019-04-07 14:15:56 --> Severity: error --> Exception: Call to undefined method CI_Session::user_data() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 82
ERROR - 2019-04-07 14:17:02 --> Severity: Warning --> Illegal offset type in isset or empty C:\xampp\htdocs\codeigniter\system\libraries\Session\Session.php 749
ERROR - 2019-04-07 14:17:02 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:17:50 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:17:51 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:19:59 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:20:01 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:20:53 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:20:54 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:21:04 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:22:43 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:22:44 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:23:09 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:23:18 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:23:19 --> Severity: error --> Exception: Call to undefined method Users::session() C:\xampp\htdocs\codeigniter\application\controllers\Users.php 105
ERROR - 2019-04-07 14:23:51 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:27:04 --> 404 Page Not Found: Images/agency
ERROR - 2019-04-07 14:27:13 --> Severity: Warning --> Illegal offset type C:\xampp\htdocs\codeigniter\system\libraries\Session\Session.php 797
ERROR - 2019-04-07 14:28:25 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\xampp\htdocs\codeigniter\application\controllers\Users.php 83
ERROR - 2019-04-07 14:29:47 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\codeigniter\application\views\school\panel.php 10
ERROR - 2019-04-07 14:30:02 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\codeigniter\application\controllers\Users.php 106
ERROR - 2019-04-07 14:30:21 --> Severity: error --> Exception: syntax error, unexpected '<', expecting end of file C:\xampp\htdocs\codeigniter\application\views\school\panel.php 10
ERROR - 2019-04-07 14:36:30 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:36:56 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:47:30 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:48:48 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:49:38 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:50:27 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:56:35 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:56:44 --> 404 Page Not Found: User/images
ERROR - 2019-04-07 14:57:41 --> 404 Page Not Found: Update/index
ERROR - 2019-04-07 15:00:09 --> 404 Page Not Found: Users/update
ERROR - 2019-04-07 15:01:07 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\codeigniter\application\controllers\Users.php 119
ERROR - 2019-04-07 15:02:06 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\codeigniter\application\controllers\Users.php 119
ERROR - 2019-04-07 15:02:08 --> Severity: error --> Exception: syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\codeigniter\application\controllers\Users.php 119
ERROR - 2019-04-07 15:02:22 --> Severity: Warning --> Missing argument 1 for Users::update(), called in C:\xampp\htdocs\codeigniter\system\core\CodeIgniter.php on line 532 and defined C:\xampp\htdocs\codeigniter\application\controllers\Users.php 116
