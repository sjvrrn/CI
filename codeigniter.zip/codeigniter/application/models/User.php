<?php
//defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Model {

/*
 *construct
 */
public function __construct(){

	parent::__construct();
	 $this->load->database();  
	//$this->load->library('database');

}
/*
 *signup
 */
public function signup($request)
{

$signup = $this->db->insert('user',$request);
if($signup)
	return true;
else
	return false;

}
/*
 *login
 */
public function login($request)
{
$email = $request['email'];
$password = (int)$request['password'];
$query = $this->db->get_where('user',array('email'=>$email,'password'=>$password));
$data =  $query->result(); 
return $data[0];                   
}

}
